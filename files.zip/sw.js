// NightBase Service Worker v1.0
const CACHE_NAME = 'nightbase-v1';
const OFFLINE_URL = '/offline.html';

// Súbory na cachovanie pri inštalácii
const PRECACHE = [
  '/',
  '/nightbase-preview.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
];

// === INSTALL — precache ===
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(PRECACHE.map(url => new Request(url, {cache: 'reload'})));
    }).then(() => self.skipWaiting())
  );
});

// === ACTIVATE — vymaž staré cachy ===
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// === FETCH — network first, cache fallback ===
self.addEventListener('fetch', event => {
  // Ignoruj non-GET a cross-origin requesty
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== location.origin) return;

  event.respondWith(
    fetch(event.request)
      .then(response => {
        // Ulož do cache iba úspešné odpovede
        if (response && response.status === 200 && response.type === 'basic') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
